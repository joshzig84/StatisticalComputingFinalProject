Winner<-function(team1,team2){
attach(football)
TeamCheck<-c("Arizona Cardinals", "Atlanta Falcon", "Baltimore Ravens", "Buffalo Bills", "Carolina Panthers", "Chicago Bears", "Cincinnati Bengals", "Cleveland Browns", "Dallas Cowboys", "Denver Broncos", "Detroit Lions", "Green Bay Packers", "Houston Texans", "Indianapolis Colts", "Jacksonville Jaguars", "Kansas City Chiefs", "Los Angeles Chargers", "Los Angeles Rams", "Miami Dolphins", "Minnesota Vikings", "New England Patriots", "New Orleans Saints", "New York Giants", "New York Jets", "Oakland Raiders", "Philadelphia Eagles", "Pittsburgh Steelers", "San Francisco 49ers", "Seattle Seahawks", "Tampa Bay Buccaneers", "Tennessee Titans", "Washington Redskins")
if(!team1 %in% TeamCheck) stop("Incorrect Team Inputted, Try Again.")
if(!team2 %in% TeamCheck) stop("Incorrect Team Inputted, Try Again.")
FinModel<-
lm(X2021_PF_PA_Ratio~X2018_Pass_Int. + X2018_Rush_Lng + X2020_Rush_EXP)
WinRatio=fitted.values(FinModel)
comparisontable=cbind(Tm,WinRatio)
detach(football)
if(team1>team2) print(paste(team1, "win!")) else if (team2>team1) print(paste(team2, "win!")) else print("They tied.")}