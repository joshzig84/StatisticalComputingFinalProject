1. Welcome to my NFL Game Predictor...Follow these instructions to successfully use my function.

2. You have already downloaded the provided dataset and app.R file to your computer... make sure they are in the same place... you are allowed to store them where ever you like (I recommend downloads or desktop).

3. Open R and change your directory to the location that you stored the dataset and app.R file.

4. Type in the following to upload the data to R... football=read.table("footballdata.csv",header=T,sep=",")

5. Next, type source("NFLWinPredictor.R")... If you choose to change the name of the R script, just use source("") and type the new name in the quotations

6. You are now ready to use the function.  To call it, type Winner.  After Winner, use parenthesis and type in 2 different team names in quotations separated by commas.

6.1. Ex: Winner("Pittsburgh Steelers","New England Patriots")

7. The tutorial to using my function is complete.  Feel free to explore all the different team combinations, and I hope you enjoy using my R function!

8. Team Names are not up to date, so the following list of teams are those that work with this function

Team Names:
"Arizona Cardinals"
"Atlanta Falcons"
"Baltimore Ravens"
"Buffalo Bills"
"Carolina Panthers"
"Chicago Bears"
"Cincinnati Bengals" 
"Cleveland Browns" 
"Dallas Cowboys" 
"Denver Broncos" 
"Detroit Lions" 
"Green Bay Packers" 
"Houston Texans" 
"Indianapolis Colts" 
"Jacksonville Jaguars" 
"Kansas City Chiefs" 
"Los Angeles Chargers" 
"Los Angeles Rams" 
"Miami Dolphins" 
"Minnesota Vikings" 
"New England Patriots" 
"New Orleans Saints" 
"New York Giants" 
"New York Jets" 
"Oakland Raiders" 
"Philadelphia Eagles" 
"Pittsburgh Steelers" 
"San Francisco 49ers" 
"Seattle Seahawks" 
"Tampa Bay Buccaneers" 
"Tennessee Titans" 
"Washington Redskins"

IMPORTANT NOTES:
1. The model this function uses only has an adjusted R-squared of about 0.3, so have fun with it, but I do not reccomend betting on sports with it.